package MultipleImplementation;

public interface Identifiable {
    String getID();
}
